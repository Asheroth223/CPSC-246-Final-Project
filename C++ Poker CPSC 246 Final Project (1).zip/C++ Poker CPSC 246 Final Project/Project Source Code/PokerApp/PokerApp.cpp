// PokerApp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <ctime>
#include <string>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <iostream>
#include <Windows.h>
#include "Bot.h"
#include "Card.h"
#include "Deck.h"
#include "Balance.h"
#include "Hand.h"
#include "Player.h"
#include "Pot.h"
using namespace std;

int main()
{	//Declare variables
	const int STARTING_DRAW = 2;
	const int ROUNDS = 4;
	const int DELAY = 600;
	int playerCount = 0;
	int dealerStart;
	int smallBlind;
	int bigBlind;
	int count = 0;
	int amount = 0;
	int turnChoice = 1;
	int betAmount;
	int playersFolded = 0;
	int betsLeft = 0;
	int loop = 1;
	string playerName;
	bool roundGoing = true;
	bool playerLeft = true;
	bool playerQuitValid = true;
	char playerQuit;
	string userTurn = "";
	Pot pot;
	Player handWinner;
	vector<Player> players;
	vector<Player> bots;
	vector<Player> playerSuits;
	vector<Player> playerValues;
	vector<string> winnerNames;
	Deck* deckInstance = Deck::getInstance();
	deckInstance->shuffleDeck();
	Hand sharedCards(deckInstance);

	cout << R"(
  _______ ________   __           _____    _    _  ____  _      _____  ______ __  __
 |__   __|  ____\ \ / /    /\    / ____|  | |  | |/ __ \| |    |  __ \|  ____|  \/  |
    | |  | |__   \ V /    /  \  | (___    | |__| | |  | | |    | |  | | |__  | \  / |
    | |  |  __|   > <    / /\ \  \___ \   |  __  | |  | | |    | |  | |  __| | |\/| |
    | |  | |____ / . \  / ____ \ ____) |  | |  | | |__| | |____| |__| | |____| |  | |
    |_|  |______/_/ \_\/_/    \_\_____/   |_|  |_|\____/|______|_____/|______|_|  |_|      
___________________________________________________________________________________________                                                        

	)" << endl;
	do { //gets the amount of players, min of 4 and max of 7
		cout << "How many bots do you want? (3-6) \n";
		cin >> playerCount;
		playerCount++;
	} while (playerCount > 7 || playerCount < 4);
	Sleep(DELAY);
	cout << "Each player will start with 1000. \n";
	cout << endl;
	Sleep(DELAY);

	for (int i = 0; i < playerCount; i++) //Gather player names, creates players with the single deck
	{
		players.push_back(Player(deckInstance));
		if (i == 0)
		{
			cout << "What is this player's name? \n";
			cin >> playerName;
			players[i].setName(playerName);
		}
		if (i != 0)
		{
			cout << "What is this bot's name? \n";
			cin >> playerName;
			players[i].setName(playerName);
		}
	}

	for (int a = 1; a < playerCount; a++)//make sure 1st player is not a bot
	{
		players[a].toggleIsPlayer();
	}

	cout << endl;
	srand(time(0));
	dealerStart = (rand() % playerCount);

	if (dealerStart - 1 < 0)
	{
		smallBlind = playerCount - 1;
	}
	else
	{
		smallBlind = dealerStart - 1;
	}

	if (dealerStart - 2 == -1)
	{
		bigBlind = playerCount - 1;
	}
	else if (dealerStart - 2 == -2)
	{
		bigBlind = playerCount - 2;
	}
	else
	{
		bigBlind = dealerStart - 2;
	}

	players[dealerStart].toggleDealer(); //Toggles for dealer and blinds
	players[smallBlind].toggleSmallBlind();
	players[bigBlind].toggleBigBlind();

	for (int i = 0; i < playerCount; ++i) //Pre round determinations
	{
		if (players[i].getBigBlind() == true)
		{
			cout << players[i].getName() << " starts as big blind.\n"; 
			Sleep(DELAY);
		}
		if (players[i].getSmallBlind() == true)
		{
			cout << players[i].getName() << " starts as small blind.\n";
			Sleep(DELAY);
		}
		if (players[i].getDealer() == true)
		{
			cout << players[i].getName() << " starts as dealer.\n";
			Sleep(DELAY);
		}
	}

	cout << endl;

	while (playerLeft == true)
	{
		//draw cards
		for (int k = 0; k < STARTING_DRAW; k++)
		{
			for (int i = 0; i < playerCount; ++i)
			{
				players[i].drawCard();
				if (players[i].getBigBlind() == true && k == 0) //Places initial bets from big blind/small blind and sets rest of players for normal blind, k == 0 to ensure only done once
				{
					players[i].setBetAmount(0);
					players[i].placeBet(50);
					players[i].removeBalance(50);
					pot.addAmt(50);
				}
				else if (players[i].getSmallBlind() == true && k == 0)
				{
					players[i].setBetAmount(25);
					players[i].placeBet(25);
					players[i].removeBalance(25);
					pot.addAmt(25);
				}
				else
				{
					players[i].setBetAmount(50);
				}
			}
		}

		while (players[1].getBigBlind() == false)
		{
			//shift vector until player 0 starts
			rotate(players.begin(), players.begin() + 1, players.end());
		}

		cout << "-----------------------------------------START OF ROUND ------------------------------------------------------------" << endl;
		cout << endl;
		Sleep(DELAY);

		for (loop = 1; loop <= ROUNDS; ++loop) //Loop for rounds, still have to make sure betAmount is 0 before continuing to next round
		{
			//for (int i = 0; i < playerCount; ++i) //loops player count
			betsLeft = playerCount;
			int i = 0;
			do
			{
				if (players[i].getFolded() == false) //checks if player is folded or not
				{
					if (loop == 2)
					{
						players[i].addSharedCard(sharedCards.getCard(0));
						players[i].addSharedCard(sharedCards.getCard(1));
						players[i].addSharedCard(sharedCards.getCard(2));
					}
					else if (loop == 3)
					{
						players[i].addSharedCard(sharedCards.getCard(3));
					}
					else if (loop == 4)
					{
						players[i].addSharedCard(sharedCards.getCard(4));
					}
					if (players[i].getIsPlayer() == true) //determine if player or bot
					{
						cout << "Your cards are \n"; //Output decision based info
						players[i].printHand();
						Sleep(DELAY);
						//cout << players[i].calcHandVal();
						cout << "\nThe community cards are: \n";
						sharedCards.PrintCards();
						Sleep(DELAY);
						cout << "\nThe bet on the table is " << players[i].getBetAmount() << endl;
						cout << "Your balance currently is " << players[i].getBalance() << endl;
						cout << "The pot currently sits at " << pot.getPot() << endl;
						cout << endl;
						Sleep(DELAY);
						do {
							if (turnChoice != 3 && turnChoice != 2 && turnChoice != 1)
							{
								cout << "Please enter a valid option" << endl;
							}
							cout << "What would you like to do " << players[i].getName() << "? (1. Call/Check 2. Bet 3. Fold)";
							cin >> turnChoice;
						} while (turnChoice != 3 && turnChoice != 2 && turnChoice != 1);
					}
					else if (players[i].getIsPlayer() == false)
					{
						cout << players[i].getName() << " has called!\n";
						cout << endl;
						turnChoice = 1;
						Sleep(DELAY);
					}
					if (turnChoice == 1) //For call/check
					{
						if (players[i].getBalance() < players[i].getBetAmount())
						{
							players[i].call(players[i].getBalance());
							pot.addAmt(players[i].getBalance());
						}
						else
						{
							players[i].placeBet(players[i].getBetAmount());
							pot.addAmt(players[i].getBetAmount());
						}
						betsLeft--;
						players[i].setBetAmount(0);
						cout << "Balance Remaining: " << players[i].getBalance() << endl;
						Sleep(DELAY);
					}
					else if (turnChoice == 2) //For bet
					{
						cout << "How much would you like to bet? \n";
						cin >> betAmount;
						Sleep(DELAY);
						if (betAmount <= players[i].getBalance() && betAmount >= 0)
						{
							players[i].placeBet(betAmount);
							players[i].removeBalance(betAmount);
						}
						else
						{
							cout << "Invalid bet amount. Try again:\n";
							cin >> betAmount;
							Sleep(DELAY);
							while (betAmount >= players[i].getBalance() || betAmount < 0)
							{
								cout << "Invalid bet amount \n";
								cin >> betAmount;
								Sleep(DELAY);
								if (betAmount <= players[i].getBalance() && betAmount > 0)
								{ 
									break; 
								}
							}
						}
						pot.addAmt(betAmount);
						for (int k = 0; k < playerCount; k++)
						{
							players[k].setBetAmount(betAmount);
						}
						players[i].setBetAmount(0);
						betsLeft = playerCount - 1;
						cout << "Balance Remaining: " << players[i].getBalance() << endl;
						Sleep(DELAY);
					}
					else if (turnChoice == 3) //for folding
					{
						players[i].toggleIsFold();
						cout << "You have folded this hand." << endl;
						playersFolded++;
						betsLeft--;
						Sleep(DELAY);
					}
					cout << endl;
					i++;

					if (betsLeft > 0 && i == playerCount)
					{
						i = 0;
					}
				}
				else if (players[i].getFolded() == true)
				{
					cout << "You are folded" << endl;
					sharedCards.PrintCards();
					if (loop == 2)
					{
						players[i].addSharedCard(sharedCards.getCard(0));
						players[i].addSharedCard(sharedCards.getCard(1));
						players[i].addSharedCard(sharedCards.getCard(2));
					}
					else if (loop == 3)
					{
						players[i].addSharedCard(sharedCards.getCard(3));
					}
					else if (loop == 4)
					{
						players[i].addSharedCard(sharedCards.getCard(4));
					}
					i++;
					betsLeft--;
					Sleep(DELAY);
				}
			} while (betsLeft != 0);

			if (loop == 1) //Will draw flop, turn, and river based on the round
			{
				sharedCards.drawCard();
				sharedCards.drawCard();
				sharedCards.drawCard();
			}
			else if (loop == 2)//turn
			{
				sharedCards.drawCard();
			}
			else if (loop == 3)//river
			{
				sharedCards.drawCard();
			}
			else if (loop == 4)//winner determination
			{
				for (int i = 0; i < playerCount; i++)
				{
					players[i].calcHandVal();
				}

				handWinner = players[0];
				winnerNames.push_back(players[0].getName());

				for (int j = 0; j < playerCount; j++)
				{
					if (players[j].getFolded() == false)
					{
						if (players[j].calcHandVal() > handWinner.calcHandVal())
						{
							handWinner = players[j];
							winnerNames.erase(winnerNames.begin(), winnerNames.end());
							winnerNames.push_back(players[j].getName());
						}
						else if (players[j].calcHandVal() == handWinner.calcHandVal())
						{
							winnerNames.push_back(players[j].getName());
						}
					}
				}
				if (winnerNames.size() == 1)
				{
					cout << "Winner is: " << handWinner.getName() << " with a hand of \n";
					handWinner.printHand();
					sharedCards.PrintCards();
					Sleep(DELAY);
					cout << endl;
					cout << "They won: " << pot.getPot() << endl;
					Sleep(DELAY);
					for (int j = 0; j < playerCount; ++j)
					{
						if (handWinner.getName() == players[j].getName())
						{
							players[j].addBalance(pot.getPot());
						}
					}
				}
				if (winnerNames.size() > 1)
				{
					sort(winnerNames.begin(), winnerNames.end());
					winnerNames.erase(unique(winnerNames.begin(), winnerNames.end()), winnerNames.end());

					cout << "Multiple Winners:" << endl;
					for (int j = 0; j < winnerNames.size(); j++)
					{
						cout << "Winner " << j+1 << ": " << winnerNames[j] << endl;
					}
					Sleep(DELAY);
					cout << endl;
					for (int k = 0; k < winnerNames.size(); ++k)
					{
						for (int j = 0; j < players.size(); j++)
						{
							if (winnerNames[k] == players[j].getName())
							{
								players[j].addBalance((pot.getPot() / winnerNames.size()));
							}
						}
					}

					cout << "They split a pot of: " << pot.getPot() << endl;
					Sleep(DELAY);
					cout << "Each player gets: " << (pot.getPot() / winnerNames.size()) << endl;
				}
			}

			cout << "-----------------------------------------END OF ROUND ------------------------------------------------------------" << endl;
			cout << endl;
		}

		for (int k = 0; k < playerCount; k++)
		{
			players[k].clearHand();

			if (players[k].getFolded() == true)
			{
				players[k].toggleIsFold();
			}
		}

		for (int k = 0; k < playerCount; k++)
		{
			if (players[k].getIsPlayer() == true && players[k].getBalance() == 0)
			{
				cout << "Sorry, you lost!" << endl;
				playerLeft = false;
				return 0;
			}
		}

		do {
			if (playerQuitValid == true)
			{
				cout << "Would you like to quit? (Y/N)" << endl;
				cin >> playerQuit;
			}
			else
			{
				cout << "Please enter a valid choice (Y/N)" << endl;
				cin >> playerQuit;
			}
			if (playerQuit == 'y' || playerQuit == 'Y' || playerQuit == 'n' || playerQuit == 'N')
			{
				playerQuitValid = true;
			}
			else
			{
				playerQuitValid = false;
			}
		} while (playerQuitValid == false);


		if (playerQuit == 'Y' || playerQuit == 'y')
		{
			for (int j = 0; j < playerCount; j++)
			{
				if (players[j].getIsPlayer() == true)
				{
					cout << "You have escaped the table with " << players[j].getBalance() << endl;
					if (players[j].getBalance() > 1000)
					{
						cout << "Congratulations!" << endl;
					}
					else
					{
						cout << "Good thing you left when you did..." << endl;
					}
				}
			}
			return 0;
		}

		for (int i = 0; i < playerCount; ++i) //Pre round determinations
		{
			if (players[i].getBigBlind() == true)
			{
				players[i].toggleBigBlind();
				if (i + 1 < (playerCount - 1))
				{
					players[i + 1].toggleBigBlind();
				}
				else
				{
					players[0].toggleBigBlind();
				}
				if (i + 2 < (playerCount - 1))
				{
					players[i + 2].toggleSmallBlind();
				}
				else
				{
					players[playerCount - i].toggleSmallBlind();
				}
				if (i + 3 < (playerCount - 1))
				{
					players[i + 3].toggleDealer();
				}
				else
				{
					players[playerCount - i].toggleDealer();
				}
			}
		}

		pot.resetPot();
		deckInstance->resetDeck();
		deckInstance->shuffleDeck();
		sharedCards.clearHand();
		
	}

	return 0;
}
