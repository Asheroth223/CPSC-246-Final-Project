#pragma once
class Pot
{
private:
	int potAmount;

public:
	Pot();
	~Pot();

	void addAmt(int bet);
	void resetPot();

	int getPot();

};

