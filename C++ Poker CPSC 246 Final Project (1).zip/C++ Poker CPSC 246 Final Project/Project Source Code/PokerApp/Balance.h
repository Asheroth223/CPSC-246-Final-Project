#pragma once
class Balance
{
private:
	int amount;

public:
	Balance();
	~Balance();

	void addBalance(int addAmt);

	void removeBalance(int remAmt);

	int getBalance();

};

