#pragma once
#include <iostream>
#include <string>
#include <cstdlib>
#include "Hand.h"
#include "Balance.h"
#include "Deck.h"
using namespace std;
class Player : public Balance
{
private:
	Hand playerHand;
	Balance playerBal;
	int betAmount;
	int handValue;

	//string nameList[6];
	string botName;
	string name;
	bool bigBlind;
	bool smallBlind;
	bool dealer;
	bool isPlayer;
	bool isTurn;
	bool isFold;
public:
	Player();
	Player(Deck* d);
	~Player();

	void setName(string);
	string getName();
	string giveName();

	int setBetAmount(int);
	int getBetAmount();

	bool toggleBigBlind();
	bool toggleSmallBlind();
	bool toggleDealer();
	bool getBigBlind();
	bool getSmallBlind();
	bool getDealer();

	bool toggleIsTurn();
	bool toggleIsFold();
	bool getFolded();

	bool toggleIsPlayer();
	bool getIsPlayer();

	void drawCard();
	void addSharedCard(Card);
	Card getCard(int index);
	void clearHand();

	void call(int);

	void placeBet(int amt);
	void winBet(int amt);

	void printHand();

	int calcHandVal();
};

