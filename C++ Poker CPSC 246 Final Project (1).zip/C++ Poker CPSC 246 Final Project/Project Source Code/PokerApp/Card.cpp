#include "pch.h"
#include "Card.h"


Card::Card()
{
	cardVal = 0;
	cardSuit = "NONE";
}


Card::~Card()
{
}

Card::Card(string suit, int val) {
	cardSuit = suit;
	cardVal = val;
}

string Card::getSuit() {
	return cardSuit;
}

int Card::getCardVal() {
	return cardVal;
}

void Card::setSuit(string suit) {
	cardSuit = suit;
}

void Card::setCardVal(int val) {
	cardVal = val;
}
