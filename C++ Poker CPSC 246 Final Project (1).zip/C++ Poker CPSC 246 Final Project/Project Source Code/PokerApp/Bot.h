#pragma once
#include <string>
#include <iostream>
#include "Balance.h"
#include "Hand.h"
#include "Player.h"

using namespace std;

class Bot : public Player
{
private:
	Hand botHand;
	Balance botBalance;
	bool bigBlind;
	bool smallBlind;
	bool dealer;
	bool loosePassive = false;
	bool looseAggressive = false;
	bool tightPassive = false;
	bool tightAggressive = false;
	bool isPlayer;

	int betAmount;

public:
	Bot();
	Bot(Deck* d);
	~Bot();


	int fold();
	int call();
	void setPersonality();


	void isLoosePassive();
	void isLooseAggressive();
	void isTightAggressive();
	void isTightPassive();
};

