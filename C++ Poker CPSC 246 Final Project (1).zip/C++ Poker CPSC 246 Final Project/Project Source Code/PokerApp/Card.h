#pragma once
#include <stdlib.h>
#include <string>
using namespace std;

class Card
{
private:
	int cardVal;
	string cardSuit;

public:
	Card();
	~Card();

	Card(string suit, int val);
	
	string getSuit();
	
	int getCardVal();

	void setSuit(string suit);

	void setCardVal(int val);
};

