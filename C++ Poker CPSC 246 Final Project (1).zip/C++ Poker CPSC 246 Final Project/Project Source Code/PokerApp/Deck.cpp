#include "pch.h"
#include "Deck.h"
#include <time.h>
#include <iostream>

using namespace std;

Deck* Deck::instance = nullptr;

Deck::Deck()
{
	for (int count = 0; count < SUITS; count++)
	{
		for (int suitCount = 0; suitCount < VALUES; suitCount++)
		{
			switch (count)
			{
			case 0:
				cardDeck.push_back(Card("DIAMOND", suitCount + 2));
				break;
			case 1:
				cardDeck.push_back(Card("HEART", suitCount + 2));
				break;
			case 2:
				cardDeck.push_back(Card("SPADE", suitCount + 2));
				break;
			case 3:
				cardDeck.push_back(Card("CLUB", suitCount + 2));
				break;
			}
		}
	}
}


Deck::~Deck()
{
}

Deck * Deck::getInstance()
{
	if (instance == nullptr) {
		//instance is null so we have no deck, make one
		instance = new Deck();
	}

	return instance;
}

void Deck::resetDeck()
{
	this->cardDeck.clear();
	for (int count = 0; count < SUITS; count++)
	{
		for (int suitCount = 0; suitCount < VALUES; suitCount++)
		{
			switch (count)
			{
			case 0:
				this->cardDeck.push_back(Card("DIAMOND", suitCount + 2));
				break;
			case 1:
				this->cardDeck.push_back(Card("HEART", suitCount + 2));
				break;
			case 2:
				this->cardDeck.push_back(Card("SPADE", suitCount + 2));
				break;
			case 3:
				this->cardDeck.push_back(Card("CLUB", suitCount + 2));
				break;
			}
		}
	}

}

Card Deck::getTopCard()
{
	Card c = this->cardDeck.back();
	this->cardDeck.pop_back();

	return c;
}

int Deck::getCardsLeft()
{
	return this->cardDeck.size();
}

void Deck::shuffleDeck()
{
	srand(time(0));
	random_shuffle(this->cardDeck.begin(), this->cardDeck.end());

}

void Deck::printDeck()
{
	for (int i = 0; i < DECKSIZE; i++)
	{
		cout << this->cardDeck[i].getCardVal() << ":" << this->cardDeck[i].getSuit() << " " ;
	}

	cout << endl;
}
